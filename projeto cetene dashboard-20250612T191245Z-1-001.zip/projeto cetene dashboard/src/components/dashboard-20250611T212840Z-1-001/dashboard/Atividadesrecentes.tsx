import React from 'react';
import { Clock, User, BookOpen, School } from 'lucide-react';

const RecentActivity: React.FC = () => {
  const activities = [
    {
      id: 1,
      type: 'participant',
      description: 'Mariana Silva se inscreveu no projeto "Robótica para Iniciantes"',
      time: '5 minutos atrás',
      icon: <User size={16} />
    },
    {
      id: 2,
      type: 'project',
      description: 'Novo projeto "Programação para Jovens" foi lançado em São Paulo',
      time: '1 hora atrás',
      icon: <BookOpen size={16} />
    },
    {
      id: 3,
      type: 'school',
      description: 'Escola Estadual Maria José foi adicionada ao programa',
      time: '3 horas atrás',
      icon: <School size={16} />
    },
    {
      id: 4,
      type: 'participant',
      description: 'Camila Santos enviou os documentos para o projeto "Ciência de Dados"',
      time: '5 horas atrás',
      icon: <User size={16} />
    }
  ];

  return (
    <div className="flow-root">
      <ul className="-mb-8">
        {activities.map((activity, idx) => (
          <li key={activity.id}>
            <div className="relative pb-8">
              {idx !== activities.length - 1 ? (
                <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
              ) : null}
              <div className="relative flex items-start space-x-3">
                <div className={`relative px-1 ${
                  activity.type === 'participant' ? 'bg-blue-100 text-blue-600' :
                  activity.type === 'project' ? 'bg-purple-100 text-purple-600' :
                  'bg-pink-100 text-pink-600'
                } h-10 w-10 rounded-full flex items-center justify-center`}>
                  {activity.icon}
                </div>
                <div className="min-w-0 flex-1">
                  <div>
                    <div className="text-sm text-gray-800">{activity.description}</div>
                    <p className="mt-0.5 text-sm text-gray-500 flex items-center">
                      <Clock size={12} className="mr-1" />
                      {activity.time}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RecentActivity;