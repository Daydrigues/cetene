import React from 'react';
import { Users, FileText, School, BookOpen } from 'lucide-react';

const StatCards: React.FC = () => {
  const stats = [
    {
      title: 'Total de Participantes',
      value: '1,248',
      icon: <Users size={24} />,
      change: '+12%',
      period: 'desde o mês passado',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-500',
      iconColor: 'text-blue-400'
    },
    {
      title: 'Documentos Enviados',
      value: '3,782',
      icon: <FileText size={24} />,
      change: '+8%',
      period: 'desde o mês passado',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-500',
      iconColor: 'text-purple-400'
    },
    {
      title: 'Escolas Participantes',
      value: '186',
      icon: <School size={24} />,
      change: '+5%',
      period: 'desde o mês passado',
      bgColor: 'bg-pink-50',
      textColor: 'text-pink-500',
      iconColor: 'text-pink-400'
    },
    {
      title: 'Projetos Ativos',
      value: '42',
      icon: <BookOpen size={24} />,
      change: '+3%',
      period: 'desde o mês passado',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-500',
      iconColor: 'text-blue-400'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {stats.map((stat, index) => (
        <div key={index} className={`${stat.bgColor} rounded-xl p-6 shadow-sm transition-all duration-300 hover:shadow-md`}>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">{stat.title}</p>
              <p className={`${stat.textColor} text-2xl font-bold mt-2`}>{stat.value}</p>
            </div>
            <div className={`${stat.iconColor} p-3 rounded-full ${stat.bgColor} bg-opacity-70`}>
              {stat.icon}
            </div>
          </div>
          <div className="mt-4">
            <span className="text-green-500 text-sm font-medium">{stat.change}</span>
            <span className="text-gray-500 text-sm ml-1">{stat.period}</span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatCards;