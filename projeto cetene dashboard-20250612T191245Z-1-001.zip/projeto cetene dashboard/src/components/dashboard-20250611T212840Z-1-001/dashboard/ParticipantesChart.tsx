import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const ParticipantsChart: React.FC = () => {
  const data = [
    { name: 'Escola Regular', value: 280 },
    { name: 'Escola Integral', value: 320 },
    { name: 'Escola Técnica', value: 180 },
    { name: 'Instituto Federal', value: 150 },
    { name: 'Escola Particular', value: 210 },
    { name: 'EJA', value: 108 }
  ];
  
  const COLORS = ['#7CB9E8', '#B19CD9', '#FFCCF9', '#FFD580', '#98FB98', '#DDA0DD'];
  
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            formatter={(value: any) => [`${value} participantes`, 'Quantidade']}
            contentStyle={{ borderRadius: '8px', borderColor: '#e5e7eb' }}
          />
          <Legend layout="vertical" verticalAlign="middle" align="right" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ParticipantsChart;