// BrazilMap.tsx
// Componente que renderiza um mapa interativo do Brasil com dados de participação por estado

import React, { useState } from 'react';
import { stateData } from '../../data/mockData';

interface TooltipState {
  content: React.ReactNode;
  position: { x: number; y: number };
}

const BrazilMap: React.FC = () => {
  // Estado para controle de interação
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [hoveredState, setHoveredState] = useState<string | null>(null);
  
  // Função para determinar a cor do estado baseado na quantidade de participantes
  const getStateColor = (stateCode: string) => {
    const state = stateData.find(s => s.code === stateCode);
    
    if (!state) return '#e5e7eb'; // Cor padrão para estados sem dados
    
    // Cores diferentes para estados selecionados/hover
    if (hoveredState === stateCode || selectedState === stateCode) {
      return state.participantCount > 100 ? '#7CB9E8' : 
             state.participantCount > 50 ? '#B19CD9' : '#FFCCF9';
    }
    
    // Cores normais baseadas na quantidade de participantes
    return state.participantCount > 100 ? '#93C5FD' : 
           state.participantCount > 50 ? '#C4B5FD' : '#FCE7F3';
  };
  
  // Manipulador de clique no estado
  const handleStateClick = (stateCode: string) => {
    setSelectedState(stateCode === selectedState ? null : stateCode);
  };
  
  // Gerador de conteúdo do tooltip
  const getTooltipContent = (stateCode: string) => {
    const state = stateData.find(s => s.code === stateCode);
    if (!state) return null;
    
    return (
      <div className="bg-white shadow-lg rounded-lg p-3 z-50 min-w-[200px]">
        <h3 className="font-bold text-gray-800">{state.name}</h3>
        <div className="mt-2">
          <p className="text-sm text-gray-600">
            <span className="font-medium">Participantes:</span> {state.participantCount}
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-medium">Projetos:</span> {state.projectCount}
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-medium">Escolas:</span> {state.schoolCount}
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="relative h-[500px] w-full overflow-auto">
      <div className="flex h-full min-w-[800px]">
        <div className="w-3/4 h-full relative">
          <svg
            viewBox="0 0 800 800"
            className="w-full h-full"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Região Norte */}
            <path
              d="M400 200 L500 180 L600 220 L580 300 L500 320 L420 280 Z"
              fill={getStateColor('AM')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('AM')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('AM')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M600 220 L650 200 L670 260 L640 300 L580 300 Z"
              fill={getStateColor('PA')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('PA')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('PA')}
              className="cursor-pointer transition-colors duration-300"
            />
            
            {/* Região Nordeste */}
            <path
              d="M670 260 L720 280 L700 340 L650 320 L640 300 Z"
              fill={getStateColor('MA')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('MA')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('MA')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M700 340 L740 360 L720 400 L680 380 L650 320 Z"
              fill={getStateColor('CE')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('CE')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('CE')}
              className="cursor-pointer transition-colors duration-300"
            />
            
            {/* Região Centro-Oeste */}
            <path
              d="M500 320 L580 300 L600 380 L520 400 Z"
              fill={getStateColor('MT')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('MT')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('MT')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M520 400 L600 380 L620 440 L540 460 Z"
              fill={getStateColor('GO')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('GO')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('GO')}
              className="cursor-pointer transition-colors duration-300"
            />
            
            {/* Região Sudeste */}
            <path
              d="M620 440 L680 420 L700 480 L640 500 L620 480 Z"
              fill={getStateColor('MG')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('MG')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('MG')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M620 480 L640 500 L620 540 L600 520 Z"
              fill={getStateColor('SP')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('SP')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('SP')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M640 500 L700 480 L720 520 L680 540 L620 540 Z"
              fill={getStateColor('RJ')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('RJ')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('RJ')}
              className="cursor-pointer transition-colors duration-300"
            />
            
            {/* Região Sul */}
            <path
              d="M600 520 L620 540 L600 580 L580 560 Z"
              fill={getStateColor('PR')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('PR')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('PR')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M580 560 L600 580 L580 620 L560 600 Z"
              fill={getStateColor('SC')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('SC')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('SC')}
              className="cursor-pointer transition-colors duration-300"
            />
            <path
              d="M560 600 L580 620 L560 660 L540 640 Z"
              fill={getStateColor('RS')}
              stroke="#fff"
              strokeWidth="2"
              onMouseEnter={() => setHoveredState('RS')}
              onMouseLeave={() => setHoveredState(null)}
              onClick={() => handleStateClick('RS')}
              className="cursor-pointer transition-colors duration-300"
            />
          </svg>
          
          {/* Tooltip */}
          {hoveredState && (
            <div 
              className="absolute pointer-events-none"
              style={{ 
                left: '50%', 
                top: '50%',
                transform: 'translate(-50%, -50%)' 
              }}
            >
              {getTooltipContent(hoveredState)}
            </div>
          )}
        </div>
        
        {/* Legenda */}
        <div className="w-1/4 p-4">
          <h3 className="font-semibold text-gray-700 mb-2">Legenda</h3>
          <div className="space-y-2">
            <div className="flex items-center">
              <div className="w-4 h-4 rounded bg-blue-300 mr-2"></div>
              <span className="text-sm text-gray-600">Mais de 100 participantes</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 rounded bg-purple-300 mr-2"></div>
              <span className="text-sm text-gray-600">Entre 50-100 participantes</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 rounded bg-pink-200 mr-2"></div>
              <span className="text-sm text-gray-600">Menos de 50 participantes</span>
            </div>
          </div>
          
          {/* Informações do estado selecionado */}
          {selectedState && (
            <div className="mt-6 p-3 bg-gray-50 rounded-lg">
              {getTooltipContent(selectedState)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BrazilMap;