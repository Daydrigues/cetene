import React from 'react';
import { projects } from '../../data/mockData';
import { CheckCircle2, Clock, AlertTriangle, XCircle } from 'lucide-react';

const ProjectsOverview: React.FC = () => {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Projeto
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Estado
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Participantes
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Fase
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {projects.slice(0, 5).map((project) => (
            <tr key={project.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">{project.name}</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{project.state}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{project.participants}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="relative w-32 h-2 bg-gray-200 rounded">
                    <div 
                      className="absolute h-full bg-blue-500 rounded"
                      style={{ 
                        width: `${project.phase === 'Inscrição' ? '20%' : 
                               project.phase === 'Seleção' ? '40%' :
                               project.phase === 'Execução' ? '60%' :
                               project.phase === 'Avaliação' ? '80%' : '100%'}` 
                      }}
                    ></div>
                  </div>
                  <span className="ml-2 text-xs text-gray-600">{project.phase}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full items-center
                  ${project.status === 'Ativo' ? 'bg-green-100 text-green-800' : 
                    project.status === 'Pendente' ? 'bg-yellow-100 text-yellow-800' : 
                    'bg-red-100 text-red-800'}`}>
                  {project.status === 'Ativo' && <CheckCircle2 size={12} className="mr-1" />}
                  {project.status === 'Pendente' && <Clock size={12} className="mr-1" />}
                  {project.status === 'Atrasado' && <AlertTriangle size={12} className="mr-1" />}
                  {project.status === 'Encerrado' && <XCircle size={12} className="mr-1" />}
                  {project.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex justify-center mt-4">
        <button className="text-blue-500 hover:text-blue-700 text-sm font-medium">
          Ver todos os projetos →
        </button>
      </div>
    </div>
  );
};

export default ProjectsOverview;