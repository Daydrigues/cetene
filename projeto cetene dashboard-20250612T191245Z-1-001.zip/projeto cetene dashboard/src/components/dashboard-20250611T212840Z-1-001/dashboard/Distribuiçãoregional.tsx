import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const RegionalDistribution: React.FC = () => {
  const data = [
    { name: 'Norte', count: 157 },
    { name: 'Nordeste', count: 342 },
    { name: 'Centro-Oeste', count: 189 },
    { name: 'Sudeste', count: 431 },
    { name: 'Sul', count: 129 }
  ];
  
  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout="vertical"
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" />
          <YAxis dataKey="name" type="category" width={80} />
          <Tooltip 
            formatter={(value: any) => [`${value} participantes`, 'Quantidade']}
            contentStyle={{ borderRadius: '8px', borderColor: '#e5e7eb' }}
          />
          <Bar dataKey="count" fill="#B19CD9" barSize={30} radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default RegionalDistribution;