import React from 'react';
import { Menu, Search, Bell, User } from 'lucide-react';

type HeaderProps = {
  openSidebar: () => void;
};

const Header: React.FC<HeaderProps> = ({ openSidebar }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={openSidebar}
              className="text-gray-500 focus:outline-none focus:text-gray-700 md:hidden"
            >
              <Menu size={24} />
            </button>
            <div className="ml-4 md:ml-0">
              <h1 className="text-2xl font-bold text-purple-600">Futuras Cientistas</h1>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="relative mx-4 lg:mx-0">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <Search size={18} className="text-gray-400" />
              </span>
              <input
                className="w-32 sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                type="text"
                placeholder="Pesquisar..."
              />
            </div>
            
            <button className="flex mx-4 text-gray-600 focus:outline-none">
              <Bell size={24} />
            </button>
            
            <div className="relative">
              <button className="flex items-center text-gray-700 focus:outline-none">
                <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 font-medium">
                  A
                </div>
                <span className="ml-2 text-sm font-medium hidden md:block">Admin</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;