import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  X, 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  School, 
  Map, 
  FileText, 
  Settings,
  BarChart 
} from 'lucide-react';

type SidebarProps = {
  isOpen: boolean;
  closeSidebar: () => void;
};

const Sidebar: React.FC<SidebarProps> = ({ isOpen, closeSidebar }) => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  const navigation = [
    { name: 'Dashboard', icon: <LayoutDashboard size={20} />, href: '/' },
    { name: 'Participantes', icon: <Users size={20} />, href: '/participants' },
    { name: 'Projetos', icon: <BookOpen size={20} />, href: '/projects' },
    { name: 'Escolas', icon: <School size={20} />, href: '/schools' },
    { name: 'Regiões', icon: <Map size={20} />, href: '/regions' },
    { name: 'Documentos', icon: <FileText size={20} />, href: '/documents' },
    { name: 'Relatórios', icon: <BarChart size={20} />, href: '/reports' },
    { name: 'Configurações', icon: <Settings size={20} />, href: '/settings' },
  ];

  return (
    <>
      <div 
        className={`fixed inset-0 z-20 transition-opacity bg-black opacity-50 lg:hidden ${
          isOpen ? 'block' : 'hidden'
        }`}
        onClick={closeSidebar}
      ></div>

      <div 
        className={`fixed inset-y-0 left-0 z-30 w-64 overflow-y-auto transition duration-300 transform bg-white lg:translate-x-0 lg:static lg:inset-0 ${
          isOpen ? 'translate-x-0 ease-out' : '-translate-x-full ease-in'
        }`}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <div className="flex items-center">
            <span className="text-2xl font-bold text-purple-600">FC</span>
            <span className="ml-2 text-xl font-bold text-gray-800">Dashboard</span>
          </div>
          <button 
            onClick={closeSidebar} 
            className="text-gray-500 focus:outline-none focus:text-gray-700 lg:hidden"
          >
            <X size={24} />
          </button>
        </div>
        
        <nav className="px-2 py-4">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`flex items-center px-4 py-3 mt-1 text-gray-600 transition-colors duration-200 rounded-lg ${
                isActive(item.href)
                  ? 'bg-purple-50 text-purple-700'
                  : 'hover:bg-purple-50 hover:text-purple-700'
              }`}
              onClick={closeSidebar}
            >
              <span className={isActive(item.href) ? 'text-purple-600' : ''}>{item.icon}</span>
              <span className="mx-4 font-medium">{item.name}</span>
            </Link>
          ))}
        </nav>
        
        <div className="absolute bottom-0 w-full border-t p-4">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 font-medium">
              FC
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-800">Futuras Cientistas</p>
              <p className="text-xs text-gray-500">Administração</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;