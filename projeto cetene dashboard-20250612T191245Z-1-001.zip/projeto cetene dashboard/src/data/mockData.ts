// State data for map visualization
export const stateData = [
  { 
    code: 'SP', 
    name: 'São Paulo', 
    participantCount: 248, 
    projectCount: 15,
    schoolCount: 32
  },
  { 
    code: 'RJ', 
    name: 'Rio de Janeiro', 
    participantCount: 187, 
    projectCount: 12,
    schoolCount: 24
  },
  { 
    code: 'MG', 
    name: 'Minas Gerais', 
    participantCount: 156, 
    projectCount: 9,
    schoolCount: 19
  },
  { 
    code: 'BA', 
    name: 'Bahia', 
    participantCount: 124, 
    projectCount: 8,
    schoolCount: 16
  },
  { 
    code: 'RS', 
    name: 'Rio Grande do Sul', 
    participantCount: 97, 
    projectCount: 7,
    schoolCount: 14
  },
  { 
    code: 'PR', 
    name: 'Paraná', 
    participantCount: 86, 
    projectCount: 6,
    schoolCount: 12
  },
  { 
    code: 'PE', 
    name: 'Pernambuco', 
    participantCount: 79, 
    projectCount: 5,
    schoolCount: 10
  },
  { 
    code: 'CE', 
    name: 'Ceará', 
    participantCount: 68, 
    projectCount: 4,
    schoolCount: 8
  },
  { 
    code: 'PA', 
    name: 'Pará', 
    participantCount: 52, 
    projectCount: 3,
    schoolCount: 7
  },
  { 
    code: 'SC', 
    name: 'Santa Catarina', 
    participantCount: 48, 
    projectCount: 3,
    schoolCount: 6
  },
  { 
    code: 'GO', 
    name: 'Goiás', 
    participantCount: 43, 
    projectCount: 3,
    schoolCount: 5
  },
  { 
    code: 'MA', 
    name: 'Maranhão', 
    participantCount: 37, 
    projectCount: 2,
    schoolCount: 4
  },
  { 
    code: 'AM', 
    name: 'Amazonas', 
    participantCount: 32, 
    projectCount: 2,
    schoolCount: 4
  },
  { 
    code: 'ES', 
    name: 'Espírito Santo', 
    participantCount: 29, 
    projectCount: 2,
    schoolCount: 3
  },
  { 
    code: 'PB', 
    name: 'Paraíba', 
    participantCount: 27, 
    projectCount: 2,
    schoolCount: 3
  },
  { 
    code: 'RN', 
    name: 'Rio Grande do Norte', 
    participantCount: 24, 
    projectCount: 1,
    schoolCount: 3
  },
  { 
    code: 'PI', 
    name: 'Piauí', 
    participantCount: 22, 
    projectCount: 1,
    schoolCount: 2
  },
  { 
    code: 'AL', 
    name: 'Alagoas', 
    participantCount: 19, 
    projectCount: 1,
    schoolCount: 2
  },
  { 
    code: 'MT', 
    name: 'Mato Grosso', 
    participantCount: 18, 
    projectCount: 1,
    schoolCount: 2
  },
  { 
    code: 'MS', 
    name: 'Mato Grosso do Sul', 
    participantCount: 16, 
    projectCount: 1,
    schoolCount: 2
  },
  { 
    code: 'SE', 
    name: 'Sergipe', 
    participantCount: 14, 
    projectCount: 1,
    schoolCount: 1
  },
  { 
    code: 'RO', 
    name: 'Rondônia', 
    participantCount: 12, 
    projectCount: 1,
    schoolCount: 1
  },
  { 
    code: 'TO', 
    name: 'Tocantins', 
    participantCount: 10, 
    projectCount: 1,
    schoolCount: 1
  },
  { 
    code: 'AC', 
    name: 'Acre', 
    participantCount: 8, 
    projectCount: 1,
    schoolCount: 1
  },
  { 
    code: 'AP', 
    name: 'Amapá', 
    participantCount: 7, 
    projectCount: 1,
    schoolCount: 1
  },
  { 
    code: 'RR', 
    name: 'Roraima', 
    participantCount: 5, 
    projectCount: 1,
    schoolCount: 1
  },
  { 
    code: 'DF', 
    name: 'Distrito Federal', 
    participantCount: 30, 
    projectCount: 2,
    schoolCount: 3
  }
];

// Mock data for participants
export const participants = [
  {
    id: 1,
    name: 'Ana Silva',
    email: 'ana.silva@email.com',
    cpf: '123.456.789-00',
    school: 'Escola Estadual Maria José',
    schoolType: 'Escola Regular',
    status: 'Ativo'
  },
  {
    id: 2,
    name: 'Beatriz Oliveira',
    email: 'beatriz.oliveira@email.com',
    cpf: '234.567.890-11',
    school: 'Colégio São Francisco',
    schoolType: 'Escola Regular',
    status: 'Ativo'
  },
  {
    id: 3,
    name: 'Carolina Santos',
    email: 'carolina.santos@email.com',
    cpf: '345.678.901-22',
    school: 'Instituto Federal de São Paulo',
    schoolType: 'Escola Regular',
    status: 'Pendente'
  },
  {
    id: 4,
    name: 'Daniela Costa',
    email: 'daniela.costa@email.com',
    cpf: '456.789.012-33',
    school: 'Escola Técnica Estadual',
    schoolType: 'Escola Regular',
    status: 'Ativo'
  },
  {
    id: 5,
    name: 'Eduarda Pereira',
    email: 'eduarda.pereira@email.com',
    cpf: '567.890.123-44',
    school: 'Colégio Pedro II',
    schoolType: 'Escola Regular',
    status: 'Inativo'
  },
  {
    id: 6,
    name: 'Fernanda Lima',
    email: 'fernanda.lima@email.com',
    cpf: '678.901.234-55',
    school: 'Escola Municipal João XXIII',
    schoolType: 'Escola Regular',
    status: 'Ativo'
  },
  {
    id: 7,
    name: 'Gabriela Martins',
    email: 'gabriela.martins@email.com',
    cpf: '789.012.345-66',
    school: 'Colégio Estadual Tiradentes',
    schoolType: 'Escola Regular',
    status: 'Pendente'
  },
  {
    id: 8,
    name: 'Helena Rodrigues',
    email: 'helena.rodrigues@email.com',
    cpf: '890.123.456-77',
    school: 'Instituto Federal da Bahia',
    schoolType: 'Escola Regular',
    status: 'Ativo'
  },
  {
    id: 9,
    name: 'Isabela Almeida',
    email: 'isabela.almeida@email.com',
    cpf: '901.234.567-88',
    school: 'Colégio Técnico da UFMG',
    schoolType: 'Escola Regular',
    status: 'Ativo'
  },
  {
    id: 10,
    name: 'Juliana Ferreira',
    email: 'juliana.ferreira@email.com',
    cpf: '012.345.678-99',
    school: 'Escola Estadual Carlos Chagas',
    schoolType: 'Escola Regular',
    status: 'Inativo'
  }
];

// Mock data for projects with phases
export const projects = [
  {
    id: 1,
    name: 'Robótica para Iniciantes',
    state: 'São Paulo',
    description: 'Projeto voltado para o ensino de robótica básica para estudantes do ensino fundamental.',
    participants: 48,
    status: 'Ativo',
    phase: 'Execução'
  },
  {
    id: 2,
    name: 'Programação para Jovens',
    state: 'Rio de Janeiro',
    description: 'Introdução à programação para jovens do ensino médio, com foco em desenvolvimento web.',
    participants: 36,
    status: 'Ativo',
    phase: 'Seleção'
  },
  {
    id: 3,
    name: 'Ciência de Dados',
    state: 'Minas Gerais',
    description: 'Projeto para ensinar conceitos básicos de ciência de dados para estudantes universitários.',
    participants: 24,
    status: 'Pendente',
    phase: 'Inscrição'
  },
  {
    id: 4,
    name: 'Astronomia na Escola',
    state: 'Bahia',
    description: 'Atividades de observação astronômica e estudos sobre o universo para estudantes.',
    participants: 30,
    status: 'Ativo',
    phase: 'Avaliação'
  },
  {
    id: 5,
    name: 'Química Divertida',
    state: 'Rio Grande do Sul',
    description: 'Experimentos químicos divertidos e educativos para despertar o interesse pela ciência.',
    participants: 22,
    status: 'Ativo',
    phase: 'Conclusão'
  },
  {
    id: 6,
    name: 'Biologia Molecular',
    state: 'Paraná',
    description: 'Introdução à biologia molecular e técnicas de laboratório para estudantes do ensino médio.',
    participants: 18,
    status: 'Pendente',
    phase: 'Inscrição'
  },
  {
    id: 7,
    name: 'Física Experimental',
    state: 'Pernambuco',
    description: 'Experimentos práticos para ensinar conceitos de física de forma dinâmica e interativa.',
    participants: 26,
    status: 'Ativo',
    phase: 'Execução'
  },
  {
    id: 8,
    name: 'Matemática Aplicada',
    state: 'Ceará',
    description: 'Aplicações práticas da matemática em problemas do dia a dia e em outras ciências.',
    participants: 32,
    status: 'Encerrado',
    phase: 'Conclusão'
  },
  {
    id: 9,
    name: 'Tecnologia Sustentável',
    state: 'Pará',
    description: 'Desenvolvimento de projetos tecnológicos com foco em sustentabilidade e meio ambiente.',
    participants: 28,
    status: 'Ativo',
    phase: 'Execução'
  },
  {
    id: 10,
    name: 'Inteligência Artificial',
    state: 'Santa Catarina',
    description: 'Introdução aos conceitos e aplicações da inteligência artificial para jovens cientistas.',
    participants: 20,
    status: 'Pendente',
    phase: 'Seleção'
  }
];

// Schools data
export const schools = [
  {
    id: 1,
    name: 'Escola Estadual Maria José',
    state: 'São Paulo',
    city: 'São Paulo',
    phone: '(11) 3456-7890',
    studentCount: 42,
    type: 'Escola Regular'
  },
  {
    id: 2,
    name: 'Colégio São Francisco',
    state: 'Rio de Janeiro',
    city: 'Rio de Janeiro',
    phone: '(21) 2345-6789',
    studentCount: 36,
    type: 'Escola Regular'
  },
  {
    id: 3,
    name: 'Instituto Federal de São Paulo',
    state: 'São Paulo',
    city: 'Campinas',
    phone: '(19) 3456-7890',
    studentCount: 28,
    type: 'Escola Regular'
  },
  {
    id: 4,
    name: 'Escola Técnica Estadual',
    state: 'São Paulo',
    city: 'Ribeirão Preto',
    phone: '(16) 3456-7890',
    studentCount: 24,
    type: 'Escola Regular'
  },
  {
    id: 5,
    name: 'Colégio Pedro II',
    state: 'Rio de Janeiro',
    city: 'Niterói',
    phone: '(21) 3456-7890',
    studentCount: 32,
    type: 'Escola Regular'
  },
  {
    id: 6,
    name: 'Escola Municipal João XXIII',
    state: 'Minas Gerais',
    city: 'Belo Horizonte',
    phone: '(31) 3456-7890',
    studentCount: 38,
    type: 'Escola Regular'
  },
  {
    id: 7,
    name: 'Colégio Estadual Tiradentes',
    state: 'Minas Gerais',
    city: 'Juiz de Fora',
    phone: '(32) 3456-7890',
    studentCount: 26,
    type: 'Escola Regular'
  },
  {
    id: 8,
    name: 'Instituto Federal da Bahia',
    state: 'Bahia',
    city: 'Salvador',
    phone: '(71) 3456-7890',
    studentCount: 34,
    type: 'Escola Regular'
  },
  {
    id: 9,
    name: 'Colégio Técnico da UFMG',
    state: 'Minas Gerais',
    city: 'Belo Horizonte',
    phone: '(31) 2345-6789',
    studentCount: 30,
    type: 'Escola Regular'
  },
  {
    id: 10,
    name: 'Escola Estadual Carlos Chagas',
    state: 'São Paulo',
    city: 'Santos',
    phone: '(13) 3456-7890',
    studentCount: 22,
    type: 'Escola Regular'
  },
  {
    id: 11,
    name: 'Colégio Bandeirantes',
    state: 'São Paulo',
    city: 'São Paulo',
    phone: '(11) 2345-6789',
    studentCount: 40,
    type: 'Escola Regular'
  },
  {
    id: 12,
    name: 'Instituto Federal do Rio Grande do Sul',
    state: 'Rio Grande do Sul',
    city: 'Porto Alegre',
    phone: '(51) 3456-7890',
    studentCount: 36,
    type: 'Escola Regular'
  }
];