import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Participants from './pages/Participants';
import Projects from './pages/Projects';
import Schools from './pages/Schools';
import Documents from './pages/Documents';
import Regions from './pages/Regions';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Layout from './components/layout/Layout';
import './index.css';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/participants" element={<Participants />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/schools" element={<Schools />} />
          <Route path="/documents" element={<Documents />} />
          <Route path="/regions" element={<Regions />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;