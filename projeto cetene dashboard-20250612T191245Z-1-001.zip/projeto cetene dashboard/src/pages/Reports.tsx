import React from 'react';
import { BarChart2, Download, Filter } from 'lucide-react';

const Reports: React.FC = () => {
  const reports = [
    {
      title: 'Relatório de Participação',
      description: 'Análise detalhada da participação por região e estado',
      lastUpdate: '1 dia atrás',
      type: 'PDF'
    },
    {
      title: 'Desempenho dos Projetos',
      description: 'Métricas e indicadores de progresso dos projetos',
      lastUpdate: '3 dias atrás',
      type: 'Excel'
    },
    {
      title: 'Distribuição Escolar',
      description: 'Mapeamento das escolas participantes',
      lastUpdate: '1 semana atrás',
      type: 'PDF'
    },
    {
      title: 'Análise de Documentação',
      description: 'Status de documentos enviados e pendentes',
      lastUpdate: '2 dias atrás',
      type: 'Excel'
    }
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Relatórios</h1>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-4">
            <button className="flex items-center px-4 py-2 bg-purple-500 text-white rounded-lg shadow hover:bg-purple-600 transition-colors">
              <BarChart2 size={16} className="mr-2" />
              Gerar Relatório
            </button>
            <button className="flex items-center text-gray-700 bg-gray-100 hover:bg-gray-200 font-medium rounded-lg text-sm px-4 py-2.5">
              <Filter size={16} className="mr-2" />
              Filtros
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reports.map((report, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-6 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{report.title}</h3>
                  <p className="text-gray-600 text-sm mt-1">{report.description}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  report.type === 'PDF' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                }`}>
                  {report.type}
                </span>
              </div>
              
              <div className="flex justify-between items-center mt-4">
                <span className="text-sm text-gray-500">Última atualização: {report.lastUpdate}</span>
                <button className="flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium">
                  <Download size={16} className="mr-1" />
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Reports;