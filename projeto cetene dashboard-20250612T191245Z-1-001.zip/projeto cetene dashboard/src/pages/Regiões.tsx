import React from 'react';
import { MapPin, Users, School } from 'lucide-react';
import { stateData } from '../data/mockData';

const Regions: React.FC = () => {
  const regions = {
    'Norte': ['AC', 'AP', 'AM', 'PA', 'RO', 'RR', 'TO'],
    'Nordeste': ['AL', 'BA', 'CE', 'MA', 'PB', 'PE', 'PI', 'RN', 'SE'],
    'Centro-Oeste': ['DF', 'GO', 'MT', 'MS'],
    'Sudeste': ['ES', 'MG', 'RJ', 'SP'],
    'Sul': ['PR', 'RS', 'SC']
  };

  const getRegionStats = (regionStates: string[]) => {
    return stateData
      .filter(state => regionStates.includes(state.code))
      .reduce((acc, state) => ({
        participants: acc.participants + state.participantCount,
        schools: acc.schools + state.schoolCount,
        projects: acc.projects + state.projectCount
      }), { participants: 0, schools: 0, projects: 0 });
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Regiões</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(regions).map(([region, states]) => {
          const stats = getRegionStats(states);
          return (
            <div key={region} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center mb-6">
                <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-3">
                  <MapPin size={24} />
                </div>
                <h2 className="text-xl font-semibold text-gray-900">{region}</h2>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Users size={20} className="text-blue-500 mr-2" />
                    <span className="text-gray-600">Participantes</span>
                  </div>
                  <span className="font-semibold text-gray-900">{stats.participants}</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <School size={20} className="text-pink-500 mr-2" />
                    <span className="text-gray-600">Escolas</span>
                  </div>
                  <span className="font-semibold text-gray-900">{stats.schools}</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <MapPin size={20} className="text-purple-500 mr-2" />
                    <span className="text-gray-600">Estados</span>
                  </div>
                  <span className="font-semibold text-gray-900">{states.length}</span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="flex flex-wrap gap-2">
                  {states.map(state => (
                    <span key={state} className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600">
                      {state}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default Regions;