import React from 'react';
import StatCards from '../components/dashboard/StatCards';
import BrazilMap from '../components/dashboard/BrazilMap';
import ProjectsOverview from '../components/dashboard/ProjectsOverview';
import ParticipantsChart from '../components/dashboard/ParticipantsChart';
import RecentActivity from '../components/dashboard/RecentActivity';
import RegionalDistribution from '../components/dashboard/RegionalDistribution';

const Dashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Dashboard Futuras Cientistas</h1>
      
      <StatCards />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm p-4 h-full">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Distribuição por Estados</h2>
            <BrazilMap />
          </div>
        </div>
        <div>
          <div className="bg-white rounded-xl shadow-sm p-4 h-full">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Distribuição por Região</h2>
            <RegionalDistribution />
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Projetos Ativos</h2>
          <ProjectsOverview />
        </div>
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Participantes por Categoria</h2>
          <ParticipantsChart />
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Atividades Recentes</h2>
        <RecentActivity />
      </div>
    </div>
  );
};

export default Dashboard;