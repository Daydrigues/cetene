import React from 'react';
import { FileText, Search, Filter } from 'lucide-react';

const Documents: React.FC = () => {
  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Documentos</h1>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input 
              type="text"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5"
              placeholder="Buscar documentos..."
            />
          </div>
          
          <button className="flex items-center text-gray-700 bg-gray-100 hover:bg-gray-200 font-medium rounded-lg text-sm px-4 py-2.5">
            <Filter size={16} className="mr-2" />
            Filtros
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {['RG', 'CPF', 'Comprovante de Residência', 'Currículo', 'Histórico Escolar', 'Carta de Recomendação'].map((doc, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-3">
                  <FileText size={24} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">{doc}</h3>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Documentação necessária para participação nos projetos.
              </p>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Última atualização: 2 dias atrás</span>
                <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                  Ver detalhes
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Documents;