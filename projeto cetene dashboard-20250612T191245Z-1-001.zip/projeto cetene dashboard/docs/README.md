# Dashboard Futuras Cientistas - Documentação

## Visão Geral
O Dashboard Futuras Cientistas é uma aplicação web desenvolvida em React para gerenciar participantes, projetos e escolas do programa. A aplicação utiliza:

- React com TypeScript
- Tailwind CSS para estilização
- Lucide React para ícones
- React Router para navegação
- Recharts para visualização de dados

## Estrutura do Projeto

### Componentes Principais

#### Layout (`/components/layout`)
- `Layout.tsx`: Componente principal que envolve toda a aplicação
- `Header.tsx`: Barra superior com navegação e perfil
- `Sidebar.tsx`: Menu lateral com links de navegação

#### Dashboard (`/components/dashboard`)
- `KPICards.tsx`: KPI com estatísticas gerais
- `BrasilMap.tsx`: Mapa interativo do Brasil
- `ParticipantesChart.tsx`: Gráfico de distribuição de participantes
- `ProjetosOverview.tsx`: Visão geral dos projetos
- `Recenteatividades.tsx`: Atividades recentes
- `RegionalDistribuição.tsx`: Distribuição por região

### Páginas (`/pages`)
- `Dashboard.tsx`: Página inicial com visão geral
- `Participants.tsx`: Gerenciamento de participantes
- `Projects.tsx`: Gerenciamento de projetos
- `Escolas.tsx`: Gerenciamento de escolas
- `Documentos.tsx`: Gestão de documentos
- `Regiões.tsx`: Análise regional
- `Reports.tsx`: Relatórios
- `Configuração.tsx`: Configurações

### Dados (`/data`)
- `mockData.ts`: Dados simulados para desenvolvimento

## Funcionalidades Principais

### Mapa do Brasil
- Visualização interativa por estado
- Indicadores de participação por cor
- Tooltips com informações detalhadas

### Gestão de Participantes
- Listagem com filtros
- Ordenação por diferentes campos
- Status de participação
- Informações detalhadas

### Projetos
- Visualização em cards
- Filtros por status
- Estados
- Fases do projeto
- Indicadores de progresso

### Escolas
- Cadastro e gerenciamento
- Filtros por estado/cidade
- Estatísticas de participação

## Fluxo de Dados
1. Dados armazenados em `mockData.ts`
2. Componentes consomem dados via props
3. Estados gerenciados localmente com hooks
4. Atualizações refletidas em tempo real

## Estilização
- Sistema de cores:
  - Azul claro: `#7CB9E8`
  - Roxo claro: `#B19CD9`
  - Rosa claro: `#FFCCF9`
- Classes Tailwind personalizadas
- Layout responsivo
- Componentes interativos